'use strict'

module.exports = (text, replace, replaceWith) => text.replace(replace, replaceWith)
